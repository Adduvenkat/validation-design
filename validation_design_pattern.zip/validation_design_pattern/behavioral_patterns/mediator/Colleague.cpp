// ˅
#include "behavioral_patterns/mediator/Colleague.h"
#include "behavioral_patterns/mediator/Mediator.h"


// ˄

Colleague::Colleague(Mediator* mediator)
	: mediator(mediator)
	// ˅
	
	// ˄
{
	// ˅
	
	// ˄
}

Colleague::~Colleague()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
