// ˅
#include "behavioral_patterns/mediator/Mediator.h"


// ˄

Mediator::~Mediator()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
