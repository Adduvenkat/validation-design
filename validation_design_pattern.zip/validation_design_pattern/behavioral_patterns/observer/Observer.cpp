// ˅
#include "behavioral_patterns/observer/Observer.h"

// ˄

Observer::~Observer()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
