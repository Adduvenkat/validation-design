// ˅
#include "behavioral_patterns/interpreter/Node.h"

// ˄

Node::~Node()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
