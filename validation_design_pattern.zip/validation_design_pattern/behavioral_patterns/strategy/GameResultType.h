// ˅

// ˄

#ifndef BEHAVIORAL_PATTERNS_STRATEGY_GAMERESULTTYPE_H_
#define BEHAVIORAL_PATTERNS_STRATEGY_GAMERESULTTYPE_H_

// ˅

// ˄

typedef enum
{

	Win,

	Loss,

	Draw

} GameResultType;

// ˅

// ˄

#endif	// BEHAVIORAL_PATTERNS_STRATEGY_GAMERESULTTYPE_H_

// ˅

// ˄
