// ˅
#include "behavioral_patterns/strategy/HandSignal.h"
#include "behavioral_patterns/strategy/Strategy.h"

// ˄

Strategy::~Strategy()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
