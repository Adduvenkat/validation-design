// ˅
#include "behavioral_patterns/memento/Memento.h"

// ˄

Memento::Memento(const int money)
	: money(money)
	// ˅
	
	// ˄
{
	// ˅
	
	// ˄
}

int Memento::getMoney() const
{
	// ˅
	return money;
	// ˄
}

// ˅

// ˄
