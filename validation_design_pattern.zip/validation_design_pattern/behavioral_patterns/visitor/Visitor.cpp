// ˅
#include "behavioral_patterns/visitor/Visitor.h"

// ˄

Visitor::~Visitor()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
