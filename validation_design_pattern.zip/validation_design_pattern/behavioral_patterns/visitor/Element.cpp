// ˅
#include "behavioral_patterns/visitor/Element.h"

// ˄

Element::~Element()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
