// ˅
#include "behavioral_patterns/iterator/Iterator.h"

// ˄

Iterator::~Iterator()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
