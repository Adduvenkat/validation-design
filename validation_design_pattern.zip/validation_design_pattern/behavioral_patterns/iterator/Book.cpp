// ˅
#include "behavioral_patterns/iterator/Book.h"

// ˄

Book::Book(const string& title)
	: title(title)
	// ˅
	
	// ˄
{
	// ˅
	
	// ˄
}

Book::~Book()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
