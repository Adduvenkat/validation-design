// ˅
#include "behavioral_patterns/iterator/Aggregate.h"
#include "behavioral_patterns/iterator/Iterator.h"

// ˄

Aggregate::~Aggregate()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
