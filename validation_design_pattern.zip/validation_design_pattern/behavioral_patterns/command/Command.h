// ˅

// ˄

#ifndef BEHAVIORAL_PATTERNS_COMMAND_COMMAND_H_
#define BEHAVIORAL_PATTERNS_COMMAND_COMMAND_H_

// ˅

// ˄

class Command
{
	// ˅
	
	// ˄

public:

	virtual ~Command();

	virtual void execute() const = 0;

	// ˅
public:
	
protected:
	
private:
	
	// ˄
};

// ˅

// ˄

#endif	// BEHAVIORAL_PATTERNS_COMMAND_COMMAND_H_

// ˅

// ˄
