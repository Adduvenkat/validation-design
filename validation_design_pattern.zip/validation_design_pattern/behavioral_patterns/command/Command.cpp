// ˅
#include "behavioral_patterns/command/Command.h"


// ˄

Command::~Command()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
