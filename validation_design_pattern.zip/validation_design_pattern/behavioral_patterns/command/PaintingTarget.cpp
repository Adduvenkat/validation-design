// ˅
#include "behavioral_patterns/command/PaintingTarget.h"


// ˄

PaintingTarget::~PaintingTarget()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
