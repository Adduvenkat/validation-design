// ˅
#include "behavioral_patterns/state/State.h"


// ˄

State::~State()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
