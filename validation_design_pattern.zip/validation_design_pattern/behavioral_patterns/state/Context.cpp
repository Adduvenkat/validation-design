// ˅
#include "behavioral_patterns/state/Context.h"


// ˄

Context::~Context()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
