// ˅
#include "creational_patterns/abstract_factory/factory/Item.h"

// ˄

Item::Item(const string& name)
	: name(name)
	// ˅
	
	// ˄
{
	// ˅
	
	// ˄
}

Item::~Item()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
