// ˅
#include "creational_patterns/abstract_factory/factory/Factory.h"

// ˄

Factory::~Factory()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
