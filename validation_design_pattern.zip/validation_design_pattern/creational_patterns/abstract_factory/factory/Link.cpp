// ˅
#include "creational_patterns/abstract_factory/factory/Link.h"

// ˄

Link::Link(const string& name, const string& url)
	: url(url)
	// ˅
	, Item(name)
	// ˄
{
	// ˅
	
	// ˄
}

Link::~Link()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
