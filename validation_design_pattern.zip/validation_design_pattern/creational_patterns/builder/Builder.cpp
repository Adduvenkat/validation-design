// ˅
#include "creational_patterns/builder/Builder.h"

// ˄

Builder::~Builder()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
