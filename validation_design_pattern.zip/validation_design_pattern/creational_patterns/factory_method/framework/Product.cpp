// ˅
#include "creational_patterns/factory_method/framework/Product.h"

// ˄

Product::~Product()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
