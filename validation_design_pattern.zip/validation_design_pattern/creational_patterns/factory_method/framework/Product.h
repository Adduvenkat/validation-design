// ˅

// ˄

#ifndef CREATIONAL_PATTERNS_FACTORY_METHOD_FRAMEWORK_PRODUCT_H_
#define CREATIONAL_PATTERNS_FACTORY_METHOD_FRAMEWORK_PRODUCT_H_

// ˅

// ˄

class Product
{
	// ˅
	
	// ˄

public:

	virtual ~Product();

	virtual void use() const = 0;

	// ˅
public:
	
protected:
	
private:
	
	// ˄
};

// ˅

// ˄

#endif	// CREATIONAL_PATTERNS_FACTORY_METHOD_FRAMEWORK_PRODUCT_H_

// ˅

// ˄
