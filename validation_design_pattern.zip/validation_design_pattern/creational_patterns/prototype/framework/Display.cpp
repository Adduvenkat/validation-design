// ˅
#include "creational_patterns/prototype/framework/Display.h"

// ˄

Display::~Display()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
