// ˅
#include "structural_patterns/bridge/DisplayImpl.h"

// ˄

DisplayImpl::~DisplayImpl()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
