// ˅

// ˄

#ifndef STRUCTURAL_PATTERNS_ADAPTER_PRINT_H_
#define STRUCTURAL_PATTERNS_ADAPTER_PRINT_H_

// ˅

// ˄

class Print
{
	// ˅
	
	// ˄

public:

	virtual ~Print();

	virtual void printWeak() const = 0;

	virtual void printStrong() const = 0;

	// ˅
public:
	
protected:
	
private:
	
	// ˄
};

// ˅

// ˄

#endif	// STRUCTURAL_PATTERNS_ADAPTER_PRINT_H_

// ˅

// ˄
