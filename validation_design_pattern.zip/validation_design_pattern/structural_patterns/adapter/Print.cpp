// ˅
#include "structural_patterns/adapter/Print.h"

// ˄

Print::~Print()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
