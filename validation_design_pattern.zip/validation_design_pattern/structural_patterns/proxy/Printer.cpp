// ˅
#include "structural_patterns/proxy/Printer.h"

// ˄

Printer::~Printer()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
