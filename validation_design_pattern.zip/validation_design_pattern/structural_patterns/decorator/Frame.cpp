// ˅
#include "structural_patterns/decorator/Frame.h"

// ˄

Frame::Frame(const Display* display)
	: display(display)
	// ˅
	
	// ˄
{
	// ˅
	
	// ˄
}

Frame::~Frame()
{
	// ˅
	
	// ˄
}

// ˅

// ˄
